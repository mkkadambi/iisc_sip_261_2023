fs=16000;
dur=2;
whitenoise=randn(1,dur*fs);

h = fir1(100,[470 530]/(fs/2));
narrowbandnoise=filter(h,1,whitenoise);

soundsc(whitenoise,fs);
pause(dur);
soundsc(narrowbandnoise,fs);