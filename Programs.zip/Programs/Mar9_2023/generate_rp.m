
L=1000;
NFFT=1024;

Hall=[];
num=1;den=[1 -.9];
a_all=[];
Ha_all=[];

for count=1:50
e = randn(1,L);
x = filter(num,den,e);
a = lpc(x,1);

% [acf_e,lag_e]=autocorr(e,100);
% [H,W]=freqz(e,1,NFFT);

[acf_x,lag_x]=autocorr(x,100);
[H,W]=freqz(x,1,NFFT);
[Ha,Wa]=freqz(1,a,NFFT);

Hall=[Hall;abs(H')];
a_all=[a_all;a(2)];
Ha_all=[Ha_all;abs(Ha')];
end

[Horig,Worig]=freqz(num,den,NFFT);

% 
% subplot(211);plot(lag_e,acf_e);
% subplot(212);plot(W,log(abs(H)));