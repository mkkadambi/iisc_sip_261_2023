%%% model description
num=1;
den=[1 -1.8198 2.0425 -1.2714 0.4624];

%%% parameters to vary
L=300; % vary; when increases estimation of R improves and hence the model estimation
snr=50; % vary; when decreases estimation of R improves and hence the model estimation
est_odr=3;

a_all=[];k_all=[];
TOTAL=1000;
for count=1:TOTAL

e= randn(1,L);
x=filter(num,den,e);

eta = randn(1,L);

Ex=sum(x.^2);Eeta=sum(eta.^2);
xn=x+sqrt(Ex/Eeta*10^(-snr/10))*eta;

R=autocorr(xn)*sum(xn.^2);
a=-inv(toeplitz(R(1:est_odr+1)))*R(2:est_odr+2)';%[den; [1 a']]
Ef=R(1:est_odr+2)*[1;a];

k=poly2rc([1;a]');

a_all=[a_all;a'];
k_all=[k_all;k'];
end

for i=1:est_odr+1
    subplot(2,2,i);hist(a_all(:,i),10);hold on;stem(den(i+1),TOTAL/10,'r');
    stem(mean(a_all(:,i)),TOTAL/10,'g');hold off;
end
figure;kden=poly2rc(den);
for i=1:est_odr+1
    subplot(2,2,i);hist(k_all(:,i),10);hold on;stem(kden(i),TOTAL/10,'r');
    stem(mean(k_all(:,i)),TOTAL/10,'g');hold off;
end
