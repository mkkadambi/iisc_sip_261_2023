%%% model description
num=1;
den=[1 -1.8198 2.0425 -1.2714 0.4624];

%%% parameters to vary
L=200; % vary; when increases estimation of R improves and hence the model estimation
snr=50; % vary; when decreases estimation of R improves and hence the model estimation
NFFT=2^(nextpow2(L)+2);
LO=10;

call=[];

for i=1:100
    i
e= randn(1,L);
x=filter(num,den,e);

eta = randn(1,L);

Ex=sum(x.^2);Eeta=sum(eta.^2);
xn=x+sqrt(Ex/Eeta*10^(-snr/10))*eta;

S=abs(fft(xn,NFFT)).^2;
logS=log(S);
c=ifft(logS);

call=[call;c(1:513)];
end

% c1=c;
% c1([LO+1:end-(LO-2+1)])=0;
% plot(imag(fft(c1,NFFT)))

% env=exp(real(fft(c1,NFFT)));
% figure;plot(log(S));hold on;plot(log(env),'r');
% [H W]=freqz(num,den,NFFT);plot(log(abs(H)),'k');