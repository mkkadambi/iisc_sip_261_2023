%%% model description
num=1;
den=[1 -1.8198 2.0425 -1.2714 0.4624];

%%% parameters to vary
L=2^20; % vary; when increases estimation of R improves and hence the model estimation
sn=10^(-4); % vary; when decreases estimation of R improves and hence the model estimation
est_odr=3;

e= randn(1,L);
x=filter(num,den,e);

eta = sqrt(sn)*randn(1,L);
xn=x+eta;

R=autocorr(xn)*sum(xn.^2);
a=-inv(toeplitz(R(1:est_odr+1)))*R(2:est_odr+2)';
Ef=R(1:est_odr+2)*[1;a];


[H,W]=freqz(num,den);
[He,We]=freqz([1;a],den);
plot(W/pi,abs(H));
hold on;
[estH,W]=freqz(1,[1;a]');
plot(W/pi,abs(estH),'r');
plot(W/pi,abs(He),'k');

legend('Original',['Predicted with order ' num2str(est_odr+1)],'Error');