F1=320;F2=920;F3=2200; % Hz
% F1=760;F2=1320;F3=2500; % Hz
Fs=8000; % sampling
f0=150; % pitch (in Hz)
dur=2;

the1=pi*F1/(Fs/2);the2=pi*F2/(Fs/2);the3=pi*F3/(Fs/2);
r1=0.94;r2=0.95;r3=0.9;

p1=[1 -2*r1*cos(the1) r1^2];p2=[1 -2*r2*cos(the2) r2^2];p3=[1 -2*r3*cos(the3) r3^2];
den=conv(conv(p1,p2),p3);

num=1;

%%% source
N0=round(Fs/f0);
sd=.4;osc=2;
Nd=round(N0*sd);
glot=zeros(1,round(dur*Fs));
N0_seq=N0+Nd*sin(2*pi*osc/Fs*([0:length(glot)-1]));
l=1;
while l<length(glot)
    glot(l)=1;
    l=l+round(N0_seq(l));
end
%%%
gwin=gausswin(round(N0/3));
glot=conv(glot,gwin);
%%%
subplot(211);plot(glot);

speech=filter(num,den,glot);
speech=speech/max(abs(speech))*.95;
subplot(212);plot(speech);
soundsc(speech,Fs)
wavwrite(speech, Fs,['sample_vowel_' num2str(f0) '.wav']);
