num = [3.9 -2.7645 1.415 -0.5515];
den = [1 -.9618 .73 -.5315 +0.5184];
imporder=20;

disp('Poles are at:');
roots(den)
abs(roots(den))
angle(roots(den))

[H,W]=freqz(num,den);
sigma_e=1/max(abs(H));

Sxx=sigma_e^2*abs(H).^2;
plot(W/pi,Sxx);title('this is not an AR process');
xlabel('w/pi');ylabel('Power Spectrum');

%%% estimate R from G
h=impz(sigma_e*num,den,imporder);
[Rh,lags,bounds]=autocorr(h);Rh=Rh*sum(h.^2);%as autocorr normalizes

%%% get AR(N) solution
for N=4:9
    R=toeplitz(Rh(1:N));
    r=Rh(2:N+1);
    a=-inv(R)*r;
    
    hatden=[1 a'];hatnum=sqrt(hatden*Rh(1:N+1));
    [hatH,W]=freqz(hatnum,hatden);
    hat_sigma_e=1/max(abs(hatH));
    hatSxx=(hat_sigma_e)^2*abs(hatH).^2;
    
    %%% estimate r from hatnum and hatden
    hath=impz(hatnum,hatden,imporder);
    hatRh=autocorr(hath);hatRh=hatRh*sum(hath.^2);%autocorr normalizes
    
    %%%=========
    plot(W/pi,Sxx);title('x[n] is not an AR process');
    xlabel('w/pi');ylabel('Power Spectrum');hold on;
    plot(W/pi,hatSxx,'r');
    hold off
    legend('x[n]',['AR(' num2str(N) ') approx']);
    %%%=========
    
    pause
end
disp('Autocorrelation matching property');
[Rh(1:15) hatRh(1:15)]

    