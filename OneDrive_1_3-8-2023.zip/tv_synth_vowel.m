close all;
clear all;

F1b=360;F2b=2220;F3b=2960;
% F1b=760;F2b=1320;F3b=2500;
F1f=320;F2f=920;F3f=2200;
Fs=8000;
f0=150;
dur=2;

F1=linspace(F1b,F1f,round(dur*Fs));
F2=linspace(F2b,F2f,round(dur*Fs));
F3=linspace(F3b,F3f,round(dur*Fs));

r1=0.94;r2=0.95;r3=0.9;
den=[];
for i=1:length(F1)
    
    the1=pi*F1(i)/(Fs/2);the2=pi*F2(i)/(Fs/2);the3=pi*F3(i)/(Fs/2);
    p1=[1 -2*r1*cos(the1) r1^2];p2=[1 -2*r2*cos(the2) r2^2];p3=[1 -2*r3*cos(the3) r3^2];
    den(i,:)=conv(conv(p1,p2),p3);
    
end


num=1;
%%%%
den=[repmat(den(1,:),Fs/2,1);den;repmat(den(end,:),Fs/2,1)];
%%%%





%%% source
dur=dur+1;
N0=round(Fs/f0);
sd=0;osc=2;
Nd=round(N0*sd);
glot=zeros(1,round(dur*Fs));
N0_seq=N0+Nd*sin(2*pi*osc/Fs*([0:length(glot)-1]));
l=1;
while l<length(glot)
    glot(l)=1;
    l=l+round(N0_seq(l));
end
%%%
gwin=gausswin(round(N0/3));
glot=conv(glot,gwin);
%%%
subplot(211);plot(glot);







Z=zeros(1,6);
speech=F1*0;
for n=60:length(den)
    
%     figure(100);impz(num,den(i,:));pause
    
    t=impz(num,den(n,:));G=sqrt(sum(t.^2));
    temp=glot(n)-fliplr(den(n,2:end))*Z';
    Z=[Z(2:end) temp];
    speech(n)=temp;
    
%     if mod(n,1000)==0
%         figure(100);stem(t);
%         pause
%     end
    
    
    
end
speech=speech/max(abs(speech))*.95;
figure(1);subplot(212);plot(speech);
soundsc(speech,Fs)

for i=1:round(.1*Fs):length(den)
    figure(100);zplane(num,den(i,:));
    pause(.09);
end