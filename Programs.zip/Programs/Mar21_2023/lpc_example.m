clear all;clc
[d,fs]=wavread('sample.wav');

Nwin=round(.02*fs);
Nshift=round(0.02*fs);
p=10;
LPCmat=[];
Epmat=[];

NFFT=1024;
L=30;

plot([1:length(d)]/fs,d);soundsc(d,fs);
pause(1+length(d)/fs);
close all;

% sqrt(Ep*N)

for i=1:Nshift:length(d)-Nwin
    
    seg=d(i:i+Nwin-1);
    [a,E]=lpc(seg,p);
    
    LPCmat=[LPCmat;a];
    Epmat=[Epmat;E];
    
    seg_fft=fft(seg,NFFT);
    ceps_seg=ifft(log(seg_fft),NFFT);
    ceps_seg(L+1:end-(L-1))=0;
    hest=ifft(exp(fft(ceps_seg,NFFT)),NFFT);
    
    
    
%     subplot(211);plot(real(hest));subplot(212);plot(imag(hest));pause
    
    a_fft=1./fft(a,NFFT);a_fft=sqrt(E*Nwin)*abs(a_fft(1:NFFT/2+1));
    ceps_fft=fft(hest,NFFT);ceps_fft=abs(ceps_fft(1:NFFT/2+1));
    seg_fft=fft(seg,NFFT);seg_fft=abs(seg_fft(1:NFFT/2+1));
    subplot(321);plot(seg);
    subplot(323);plot(20*log10(seg_fft));hold on;plot(20*log10(a_fft),'r');hold off;
    subplot(325);plot(20*log10(seg_fft));hold on;plot(20*log10(ceps_fft),'r');hold off;pause
    
end

% Zi=zeros(1,p);
% errsig=[];count=1;
% for i=1:Nshift:length(d)-Nwin
%     
%     seg=d(i:i+Nshift-1);
%     a=LPCmat(count,:);
%     [temp Zf]=filter(a,1,seg,Zi);
%     Zi=Zf;
%     errsig=[errsig;temp];
%     count=count+1;
% end
% 
% Zi=zeros(1,p);count=1;
% estsig=[];
% for i=1:Nshift:length(d)-Nwin
%     
%     seg=randn(1,Nshift)';seg=seg/std(seg);%errsig(i:i+Nshift-1);
%     a=LPCmat(count,:);
% %     [temp Zf]=filter(1,a,seg,Zi);
%     [temp Zf]=filter(sqrt(Epmat(count)*Nshift),a,seg,Zi);
%     Zi=Zf;
% %     plot(d(i:i+Nshift-1));hold on;plot(temp,'r');hold off;pause
%     estsig=[estsig;temp];
%     count=count+1;
% end
% plot(d);hold on;plot(estsig,'r');