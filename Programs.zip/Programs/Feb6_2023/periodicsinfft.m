close all
f1=4;
fs=32;
dur=1;

t=0:1/fs:dur;
sig=sin(2*pi*f1*t);
figure(1);stem(t,sig);

NFFT=length(sig)-1;

fftsig=fft(sig,NFFT);
freq=[0:1:(NFFT-1)]*fs/NFFT;
figure(2);stem(freq,abs(fftsig));