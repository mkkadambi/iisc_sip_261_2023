% function ztransform_plot(num,den)
close all;

% num=0.9.^[0:100];
num=1;
% r1=.85;the1=pi/5;
% r2=.9;the2=pi/3;
% r3=.95;the3=2*pi/3;
% p1=[1 -2*r1*cos(the1) r1^2];p2=[1 -2*r2*cos(the2) r2^2];p3=[1 -2*r3*cos(the3) r3^2];
% den=conv(conv(p1,p2),p3);
den=[1 -.9];

step=.05;
v=-1.5:step:1.5;

numZ=[];
for i=1:length(v)
    z=v+sqrt(-1)*v(i);z=1./z;
    Zall=[];
    for k=0:1:length(num)-1
        Zall=[Zall;z.^k];
    end
    numZ=[numZ; (num*Zall)];
end



denZ=[];
for i=1:length(v)
    z=v+sqrt(-1)*v(i);z=1./z;
    Zall=[];
    for k=0:1:length(den)-1
        Zall=[Zall;z.^k];
    end
    denZ=[denZ; (den*Zall)];
end

numZ_denZ = numZ./denZ;

th=0:.01:2*pi;
r=1/step;X=r*cos(th);Y=r*sin(th);
mx=round(length(v)/2);my=mx;

[Xm,Ym]=meshgrid(v,v);
ticks = linspace(1, size(numZ, 2), numel(v));

figure;
subplot(221);imagesc(real(numZ_denZ));title('Real');colorbar;
hold on;plot(X+mx,Y+my,'y','linewidth',2);set(gca,'XTickLabel',[]);set(gca,'YTickLabel',[]);
subplot(222);imagesc(imag(numZ_denZ));title('Imag');colorbar;
hold on;plot(X+mx,Y+my,'y','linewidth',2);set(gca,'XTickLabel',[]);set(gca,'YTickLabel',[]);
subplot(223);imagesc(log(abs(numZ_denZ)));title('Magnitude');colorbar;
hold on;plot(X+mx,Y+my,'y','linewidth',2);set(gca,'XTickLabel',[]);set(gca,'YTickLabel',[]);
subplot(224);imagesc(angle(numZ_denZ));title('Phase');colorbar;
hold on;plot(X+mx,Y+my,'y','linewidth',2);set(gca,'XTickLabel',[]);set(gca,'YTickLabel',[]);


figure;
[H,W]=freqz(num,den,128);H1=[H;flipud(H)];W1=[W;W+pi];
subplot(221);plot(W1,real(H1));axis tight;title('Real');
subplot(222);plot(W1,imag(H1));axis tight;title('Imag');
subplot(223);plot(W1,abs(H1));axis tight;title('Magnitude');
subplot(224);plot(W1(1:end-1),diff(angle(H1)));axis tight;title('Phase');