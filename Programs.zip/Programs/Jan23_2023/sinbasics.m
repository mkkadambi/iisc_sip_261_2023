f1=100;f2=200;f3=300;
fs=8000;
Dur=2;
NFFT=1024*8;


% % % %%%% simple sine
% % % t=0:1/fs:Dur;
% % % signal=sin(2*pi*f1*t);%+sin(2*pi*f2*t);
% % % stem(t,signal);
% % % % NFFT=length(signal);
% % % Fsignal=fft(signal,NFFT);
% % % freq=[0:1:NFFT-1]/NFFT*fs;
% % % plot(freq(1:NFFT/2+1),20*log10(abs(Fsignal(1:NFFT/2+1))))


%%%%%%%% TV sine
t=0:1/fs:Dur;
signal=[sin(2*pi*f1*t(1:round(length(t)/3)))...
    sin(2*pi*f3*t(round(length(t)/3)+1:round(2*length(t)/3)))... 
    sin(2*pi*f2*t(round(2*length(t)/3)+1:length(t)))];

plot(t,signal);
freqz(signal,1,NFFT)