%%% Audio recording
Fs=16000;
r = audiorecorder(Fs, 16, 1);
disp('Ready to record for 3 seconds: Please speak..');
record(r);
pause(3);
disp('Recording will be over soon; Please stop...');
pause(2);
stop(r);
sig_r = getaudiodata(r, 'int16');sig_r=double(sig_r);
% plot(sig_r);
sig=sig_r/max(abs(sig_r))*.9;%normalizing between +1 -1
wavwrite(sig,Fs,'sample.wav');
soundsc(sig,Fs);


%% Half wave rectification
sig_hw=sig;
sig_hw(find(sig<=0))=0;
subplot(211);plot(sig);subplot(212);plot(sig_hw);
wavwrite(sig_hw,Fs,'sample_hw.wav');


%% Full wave rectification
sig_fw=abs(sig);
subplot(211);plot(sig);subplot(212);plot(sig_fw);
wavwrite(sig_fw,Fs,'sample_fw.wav');


%% every odd sample zero
sig_oz=sig;
sig_oz(1:2:end)=0;
subplot(211);plot(sig);subplot(212);plot(sig_oz);
wavwrite(sig_oz,Fs,'sample_oz.wav');

%% rect pulse of width W
W=20;
template=[ones(1,W) zeros(1,W)];
L=ceil(length(sig)/2/W);
for i=1:nextpow2(L)
    template=[template template];
end
template=template(1:length(sig))';
sig_rp=sig.*template;
subplot(211);plot(sig);subplot(212);plot(sig_rp);
wavwrite(sig_rp,Fs,'sample_rp.wav');
